package org.example.kindergarten_management_system_g4.constant;

public class Iconstant {

    public static final String GOOGLE_CLIENT_ID = "1028444732076-4llkdccstoav2g4bkdf3s75cj86kvl82.apps.googleusercontent.com";

    public static final String GOOGLE_CLIENT_SECRET = "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";

    public static final String GOOGLE_REDIRECT_URI = "http://localhost:8080/Kindergarten_Management_System/login_Gg";

    public static final String GOOGLE_GRANT_TYPE = "authorization_code";

    public static final String GOOGLE_LINK_GET_TOKEN = "https://accounts.google.com/o/oauth2/token";

    public static final String GOOGLE_LINK_GET_USER_INFO = "https://www.googleapis.com/oauth2/v1/userinfo?access_token=";
}
